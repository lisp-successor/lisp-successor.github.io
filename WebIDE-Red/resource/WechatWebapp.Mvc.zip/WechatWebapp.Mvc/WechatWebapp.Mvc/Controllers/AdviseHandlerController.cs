﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WechatWebapp.Model;

namespace WechatWebapp.Mvc.Controllers
{
    public class AdviseHandlerController : Controller
    {
        private EfDbContext db = new EfDbContext();

        //
        // GET: /AdviseHandler/

        public ActionResult Index()
        {
            return View(db.AdviseHandler.ToList());
        }

        //
        // GET: /AdviseHandler/Details/5

        public ActionResult Details(long id = 0)
        {
            AdviseHandler advisehandler = db.AdviseHandler.Find(id);
            if (advisehandler == null)
            {
                return HttpNotFound();
            }
            return View(advisehandler);
        }

        //
        // GET: /AdviseHandler/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /AdviseHandler/Create

        [HttpPost]
        public ActionResult Create(AdviseHandler advisehandler)
        {
            if (ModelState.IsValid)
            {
                db.AdviseHandler.Add(advisehandler);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(advisehandler);
        }

        //
        // GET: /AdviseHandler/Edit/5

        public ActionResult Edit(long id = 0)
        {
            AdviseHandler advisehandler = db.AdviseHandler.Find(id);
            if (advisehandler == null)
            {
                return HttpNotFound();
            }
            return View(advisehandler);
        }

        //
        // POST: /AdviseHandler/Edit/5

        [HttpPost]
        public ActionResult Edit(AdviseHandler advisehandler)
        {
            if (ModelState.IsValid)
            {
                db.Entry(advisehandler).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(advisehandler);
        }

        //
        // GET: /AdviseHandler/Delete/5

        public ActionResult Delete(long id = 0)
        {
            AdviseHandler advisehandler = db.AdviseHandler.Find(id);
            if (advisehandler == null)
            {
                return HttpNotFound();
            }
            return View(advisehandler);
        }

        //
        // POST: /AdviseHandler/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(long id)
        {
            AdviseHandler advisehandler = db.AdviseHandler.Find(id);
            db.AdviseHandler.Remove(advisehandler);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}