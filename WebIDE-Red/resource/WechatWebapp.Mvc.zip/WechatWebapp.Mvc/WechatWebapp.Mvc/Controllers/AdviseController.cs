﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Reflection;
using System.ComponentModel.DataAnnotations;

namespace WechatWebapp.Mvc.Controllers
{
    public class AdviseController : Controller
    {
        //不用EntityFramework的寫法,可用你們團隊的類庫或是本例附的AdoDbConnection
        //AdoDbConnection ado = new AdoDbConnection(AdoDbConnection.AdoDbType.MsSql, "Data Source=192.168.12.46;User ID=sa;PWD=84314027;Initial Catalog=AdviseDb;Persist Security Info=True");
        AdoDbConnection ado = new AdoDbConnection(AdoDbConnection.AdoDbType.SQLite, string.Format("data source=\"{0}bin\\AdviseDb.sqlite\"", AppDomain.CurrentDomain.BaseDirectory));
        IList<Advise> lstAdvise = null;

        //
        // GET: /Advise/

        public ActionResult Index()
        {
            ViewBag.lstAdviseType = Get_lstAdviseType();

            var dt = ado.loadDataTable(@"
            select * from Advise
            ", null, "Advise");
            lstAdvise = DataTableExtensions.ToList<Advise>(dt);
            return View(lstAdvise);
        }

        [HttpPost]
        public ActionResult Index(string any)
        {
            ViewBag.lstAdviseType = Get_lstAdviseType();

            var cmbAdviseType     = Request.Form["cmbAdviseType"].ToString();
            ViewBag.cmbAdviseType = cmbAdviseType;

            var txtAdviseHandleState     = Request.Form["txtAdviseHandleState"].ToString();
            ViewBag.txtAdviseHandleState = txtAdviseHandleState;
        
            var whereCondition = "";
            var lstConditionValue = new List<object>();
            if (!string.IsNullOrEmpty(cmbAdviseType))        
            { 
                whereCondition += " and AdviseType = @cmbAdviseType";
                lstConditionValue.Add(cmbAdviseType);
            }
            
            if (!string.IsNullOrEmpty(txtAdviseHandleState)) 
            { 
                whereCondition += " and AdviseHandleState = @txtAdviseHandleState";
                lstConditionValue.Add(txtAdviseHandleState);
            }

            var sql = string.Format(@"
            select * from Advise
            where 1=1 {0}
            ", whereCondition);
            var dt = ado.loadDataTable(sql, lstConditionValue.ToArray(), "Advise");
            lstAdvise = DataTableExtensions.ToList<Advise>(dt);
            return View(lstAdvise);
        }
        List<string> Get_lstAdviseType()
        {
            var lstAdviseType = new List<string>() { "" };
            var dtAdviseType = ado.loadDataTable("select distinct AdviseType from AdviseHandler ", null, "AdviseHandler");
            foreach (DataRow dr in dtAdviseType.Rows)
            { lstAdviseType.Add(dr[0].ToString()); }
            return lstAdviseType;
        }


        [HttpPost]
        public ActionResult SetAdviseType(string any)
        {
            var hdMyCheckGroup1 = Request.Form["hdMyCheckGroup1"].ToString();
            if (!string.IsNullOrEmpty(hdMyCheckGroup1))
            {
                var cmbAdviseType = Request.Form["cmbAdviseType"].ToString();
                var sql = string.Format(@"
                    UPDATE Advise
                    SET AdviseType = @cmbAdviseType
                    WHERE AdviseNo in ('{0}')
                ", String.Join("','", hdMyCheckGroup1.Split('|')));
                ado.dbNonQuery(sql, new object[] { cmbAdviseType });
            }
            return RedirectToAction("Index");
        }

    }

    public class Advise
    {
        [Display(Name = "單號")]
        public string AdviseNo { get; set; }

        [Display(Name = "工號")]
        public string UserId { get; set; }

        [Display(Name = "姓名")]
        public string UserName { get; set; }

        [Display(Name = "部門")]
        public string Dept { get; set; }

        [Display(Name = "投訴類型")]
        public string AdviseType { get; set; }

        [Display(Name = "內容")]
        public string AdviseContent { get; set; }

        [Display(Name = "投訴日期")]
        public string AdviseDateTime { get; set; }

        [Display(Name = "處理人員")]
        public Nullable<long> AdviseHandlerId { get; set; }

        [Display(Name = "處理情況")]
        public string AdviseHandleState { get; set; }
    }
}