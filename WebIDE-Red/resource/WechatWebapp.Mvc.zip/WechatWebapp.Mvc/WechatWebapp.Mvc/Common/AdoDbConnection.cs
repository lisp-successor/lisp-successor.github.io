﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Data.Common;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.Configuration;

namespace WechatWebapp   // change the namespace to same as your project namespace
{

    public class AdoDbConnection
    {
        #region GetProviderFactory(...)
        // 不是.net已经自带的DataProvider,必須修改C:\WINDOWS\Microsoft.NET\Framework\v2.0.50727\CONFIG\machine.config
        // 如果程式的執行主機上已有安裝舊版的DataProvider(其他廠商的程式)或沒有權限安裝DataProvider(雲端)
        // 只能用此法; 缺點是使用反射造成的延遲
        private static object GetPublicStaticField(Type type, string fieldName)
        {
            try
            { return type.InvokeMember(fieldName, BindingFlags.Public | BindingFlags.Static | BindingFlags.GetField, null, null, null); }
            catch (Exception e)
            { return null; }
        }
        private static Type LoadType(string assemblyName, string className)
        {
            try
            { return Assembly.Load(assemblyName).GetType(className); }
            catch (Exception e)
            { return null; }
        }

        public static DbProviderFactory GetProviderFactory(string providerName, string assemblyName, string className)
        {
            DbProviderFactory provider;

            try
            {
                provider = DbProviderFactories.GetFactory(providerName);
            }
            catch (Exception)
            {
                // dll檔必須同目錄而且assemblyName不要加副檔名
                provider = GetPublicStaticField(LoadType(assemblyName, className), "Instance") as DbProviderFactory;
            }

            if (provider == null)
            {
                string msg = "Create DbProviderFactory failed.";
                throw new Exception(msg);
            }
            return provider;
        }

        #endregion


        public enum AdoDbType : int
        { MsSql = 0, MsAccess = 1, MySQL = 2, SQLite = 3 }

        bool blnDbConnRegisted = false;
        DbCommand dbCmd = null;
        DbDataAdapter dbDa = null;
        DbCommandBuilder dbCb = null;
        public DataSet dsTemp = null;
        private void Create(bool _blnDbConnRegisted, AdoDbType _AdoDbType, string _AdoConnStr)
        {
            try
            {
                DbProviderFactory dbfc = null;

                blnDbConnRegisted = _blnDbConnRegisted;
                if (_AdoDbType == AdoDbType.MsSql || _AdoDbType == AdoDbType.MsAccess)
                { blnDbConnRegisted = true; } //已內建在system.data.dll 中

                switch (_AdoDbType)
                {
                    case AdoDbType.MsSql: { dbfc = GetProviderFactory("System.Data.SqlClient", null, null); } break;
                    case AdoDbType.MsAccess: { dbfc = GetProviderFactory("System.Data.OleDb", null, null); } break;

                    case AdoDbType.MySQL:
                        {
                            if (blnDbConnRegisted) { dbfc = GetProviderFactory("MySql.Data.MySqlClient", null, null); }
                            else { dbfc = GetProviderFactory(null, "MySql.Data", "MySql.Data.MySqlClient.MySqlClientFactory"); }
                        } break;

                    case AdoDbType.SQLite:
                        {
                            if (blnDbConnRegisted) { dbfc = GetProviderFactory("System.Data.SQLite", null, null); }
                            else { dbfc = GetProviderFactory(null, "System.Data.SQLite", "System.Data.SQLite.SQLiteFactory"); }
                        } break;
                    default: break;
                }

                if (dbfc != null)
                {
                    dbCmd = dbfc.CreateCommand();
                    dbCmd.Connection = dbfc.CreateConnection();
                    dbCmd.Connection.ConnectionString = _AdoConnStr;

                    dbDa = dbfc.CreateDataAdapter();
                    dbDa.SelectCommand = dbCmd;

                    dbCb = dbfc.CreateCommandBuilder();
                    dbCb.DataAdapter = dbDa;

                    dsTemp = new DataSet("dsTemp");
                }
            }
            catch (Exception ex)
            { string err = ex.Message; }
        }
        public AdoDbConnection(bool _blnDbConnRegisted, AdoDbType _AdoDbType, string _AdoConnStr)
        { Create(_blnDbConnRegisted, _AdoDbType, _AdoConnStr); }
        public AdoDbConnection(AdoDbType _AdoDbType, string _AdoConnStr)
        { Create(false, _AdoDbType, _AdoConnStr); }
        public AdoDbConnection(int _AdoDbType, string _AdoConnStr)
        { Create(false, (AdoDbType)_AdoDbType, _AdoConnStr); }

        private enum AdoDbAction : int
        { Select = 0, Update = 1, ExecuteNonQuery = 2, InsertExecuteReader = 3 }
        private object accessDataTable(AdoDbAction action, string strSql, object[] sqlParams, string tableNameInDs)
        {
            object re = null;

            try
            {
                dbCmd.Parameters.Clear();
                Regex theReg = new Regex(@"([@][a-z|A-Z|u4e00-u9fa5]+)");
                MatchCollection mc = theReg.Matches(strSql);
                if (sqlParams != null && mc.Count == sqlParams.Length)
                {
                    for (int i = 0; i < mc.Count; i++)
                    {
                        var dbp = dbCmd.CreateParameter();
                        dbp.ParameterName = mc[i].ToString();
                        dbp.Value = sqlParams[i];
                        dbCmd.Parameters.Add(dbp);
                    }
                }
                dbCmd.CommandText = strSql;

                if (action == AdoDbAction.Select)
                {
                    if (dsTemp.Tables[tableNameInDs] == null)
                    { dsTemp.Tables.Add(tableNameInDs); }
                    else
                    {
                        dsTemp.Tables[tableNameInDs].Dispose();
                        dsTemp.Tables.Remove(tableNameInDs);
                        dsTemp.Tables.Add(tableNameInDs);
                    }
                }

                switch (action)
                {
                    case AdoDbAction.Select: { dbDa.Fill(dsTemp, tableNameInDs); re = dsTemp.Tables[tableNameInDs]; } break;
                    case AdoDbAction.Update: { dbDa.Update(dsTemp, tableNameInDs); } break;
                    case AdoDbAction.ExecuteNonQuery: { dbCmd.Connection.Open(); dbCmd.ExecuteNonQuery(); } break;
                    case AdoDbAction.InsertExecuteReader:
                        {
                            dbCmd.CommandText += ";SELECT NewID = SCOPE_IDENTITY()";
                            dbCmd.Connection.Open();
                            var dr = dbCmd.ExecuteReader();
                            if (dr.HasRows)
                            {
                                dr.Read();
                                re = Convert.ToInt32(dr["NewID"]);
                            }
                            dr.Close();
                        } break;
                    default: break;
                }
            }
            catch (Exception ex)
            { string err = ex.Message; }
            finally
            { if (dbCmd != null && dbCmd.Connection != null) dbCmd.Connection.Close(); }

            return re;
        }

        public DataTable loadDataTable(string strSql, object[] sqlParams, string tableNameInDs)
        { return (DataTable)accessDataTable(AdoDbAction.Select, strSql, sqlParams, tableNameInDs); }
        public void updateDataTable(string strSql, object[] sqlParams, string tableNameInDs)
        { accessDataTable(AdoDbAction.Update, strSql, sqlParams, tableNameInDs); }
        public void dbNonQuery(string strSql, object[] sqlParams)
        { accessDataTable(AdoDbAction.ExecuteNonQuery, strSql, sqlParams, null); }
        public int insertAndGetIdentity(string strSql, object[] sqlParams)
        { return (int)accessDataTable(AdoDbAction.InsertExecuteReader, strSql, sqlParams, null); }
    }

    public static class DataTableExtensions
    {
        public static IList<T> ToList<T>(this DataTable table) where T : new()
        {
            IList<PropertyInfo> properties = typeof(T).GetProperties().ToList();
            IList<T> result = new List<T>();

            //取得DataTable所有的row data
            foreach (var row in table.Rows)
            {
                var item = MappingItem<T>((DataRow)row, properties);
                result.Add(item);
            }

            return result;
        }

        private static T MappingItem<T>(DataRow row, IList<PropertyInfo> properties) where T : new()
        {
            T item = new T();
            foreach (var property in properties)
            {
                if (row.Table.Columns.Contains(property.Name))
                {
                    //針對欄位的型態去轉換
                    if (property.PropertyType == typeof(DateTime))
                    {
                        DateTime dt = new DateTime();
                        if (DateTime.TryParse(row[property.Name].ToString(), out dt))
                        {
                            property.SetValue(item, dt, null);
                        }
                        else
                        {
                            property.SetValue(item, null, null);
                        }
                    }
                    else if (property.PropertyType == typeof(decimal))
                    {
                        decimal val = new decimal();
                        decimal.TryParse(row[property.Name].ToString(), out val);
                        property.SetValue(item, val, null);
                    }
                    else if (property.PropertyType == typeof(double))
                    {
                        double val = new double();
                        double.TryParse(row[property.Name].ToString(), out val);
                        property.SetValue(item, val, null);
                    }
                    else if (property.PropertyType == typeof(int))
                    {
                        int val = new int();
                        int.TryParse(row[property.Name].ToString(), out val);
                        property.SetValue(item, val, null);
                    }
                    else
                    {
                        if (row[property.Name] != DBNull.Value)
                        {
                            property.SetValue(item, row[property.Name], null);
                        }
                    }
                }
            }
            return item;
        }
    }


}