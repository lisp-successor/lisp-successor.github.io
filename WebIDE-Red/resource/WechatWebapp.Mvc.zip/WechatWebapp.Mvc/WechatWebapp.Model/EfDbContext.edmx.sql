
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 08/22/2017 22:02:48
-- Generated from EDMX file: C:\Documents and Settings\Administrator\桌面\WechatWebapp.Mvc\WechatWebapp.Model\EfDbContext.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[AdviseHandler]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AdviseHandler];
GO
IF OBJECT_ID(N'[dbo].[Advise]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Advise];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'AdviseHandler'
CREATE TABLE [dbo].[AdviseHandler] (
    [Id] int  NOT NULL,
    [AdviseType] nvarchar(50)  NOT NULL,
    [UserId] nvarchar(20)  NOT NULL,
    [UserName] nvarchar(20)  NOT NULL,
    [UserMail] nvarchar(50)  NOT NULL,
    [UserType] nvarchar(2)  NOT NULL
);
GO

-- Creating table 'Advise'
CREATE TABLE [dbo].[Advise] (
    [AdviseNo] nvarchar(20)  NOT NULL,
    [UserId] nvarchar(20)  NOT NULL,
    [UserName] nvarchar(20)  NOT NULL,
    [Dept] nvarchar(50)  NOT NULL,
    [AdviseType] nvarchar(50)  NOT NULL,
    [AdviseContent] nvarchar(8000)  NOT NULL,
    [AdviseDateTime] datetime  NOT NULL,
    [AdviseHandlerId] int  NOT NULL,
    [AdviseHandleState] nvarchar(10)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'AdviseHandler'
ALTER TABLE [dbo].[AdviseHandler]
ADD CONSTRAINT [PK_AdviseHandler]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [AdviseNo] in table 'Advise'
ALTER TABLE [dbo].[Advise]
ADD CONSTRAINT [PK_Advise]
    PRIMARY KEY CLUSTERED ([AdviseNo] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------